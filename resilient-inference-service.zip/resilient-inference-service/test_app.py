import unittest
from app import *

class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def test_deadline(self):
        async def slow(x):await asyncio.sleep(.1)
        with self.assertRaises(TimeoutError):await Service(slow,timeout=.01).predict('x')
    async def test_retry(self):
        calls=0
        async def flaky(x):
            nonlocal calls
            calls+=1
            if calls==1:raise TransientError()
            return x
        self.assertEqual(await Service(flaky).predict('ok'),'ok');self.assertEqual(calls,2)
    async def test_circuit(self):
        async def fail(x):raise TransientError()
        s=Service(fail,retries=0,failure_limit=1)
        with self.assertRaises(TransientError):await s.predict('x')
        with self.assertRaises(CircuitOpen):await s.predict('x')
    async def test_bound(self):
        active=0;peak=0
        async def provider(x):
            nonlocal active,peak
            active+=1;peak=max(peak,active)
            try:await asyncio.sleep(.001);return x
            finally:active-=1
        s=Service(provider,concurrency=2)
        await asyncio.gather(*(s.predict(i) for i in range(10)));self.assertLessEqual(peak,2)
    async def test_cancellation_propagates(self):
        async def provider(x):raise asyncio.CancelledError()
        with self.assertRaises(asyncio.CancelledError):await Service(provider).predict('x')

if __name__ == '__main__': unittest.main()
