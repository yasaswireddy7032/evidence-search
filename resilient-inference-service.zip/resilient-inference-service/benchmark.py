"""Local adapter benchmark. This measures orchestration, not LLM token throughput."""
import asyncio,argparse,json,math,statistics,time
from app import Service,TransientError,CircuitOpen
async def benchmark(n=100,concurrency=4,provider_delay=.01,timeout=2):
    active=peak=0
    async def provider(request):
        nonlocal active,peak
        active+=1;peak=max(peak,active)
        try:
            await asyncio.sleep(provider_delay)
            return request
        finally:active-=1
    service=Service(provider,concurrency=concurrency,timeout=timeout)
    async def request(i):
        started=time.perf_counter()
        try:
            await service.predict(i);status='success'
        except (TimeoutError,CircuitOpen,TransientError):status='failed'
        return {'latency_ms':(time.perf_counter()-started)*1000,'status':status}
    started=time.perf_counter();rows=await asyncio.gather(*(request(i) for i in range(n)));duration=time.perf_counter()-started
    latencies=sorted(r['latency_ms'] for r in rows);success=sum(r['status']=='success' for r in rows)
    return {'workload':'synthetic async sleep provider; all requests arrive together','requests':n,'concurrency_limit':concurrency,'observed_peak':peak,'successes':success,'failures':n-success,'duration_seconds':duration,'successful_requests_per_second':success/duration,'p50_latency_ms':statistics.median(latencies),'p95_latency_ms':latencies[math.ceil(.95*n)-1],'metrics':service.metrics}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--requests',type=int,default=100);p.add_argument('--concurrency',type=int,default=4);a=p.parse_args()
    if not 1<=a.requests<=10000 or a.concurrency<1:p.error('requests must be 1..10000 and concurrency positive')
    print(json.dumps(asyncio.run(benchmark(a.requests,a.concurrency)),indent=2))
