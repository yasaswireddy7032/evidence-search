import asyncio,time,json
class CircuitOpen(RuntimeError):pass
class TransientError(RuntimeError):pass
class Service:
    def __init__(self,provider,concurrency=3,timeout=.2,retries=1,failure_limit=3,cooldown=1):
        if concurrency<1 or timeout<=0 or retries<0 or failure_limit<1 or cooldown<0:raise ValueError('Invalid service configuration')
        self.provider=provider;self.semaphore=asyncio.Semaphore(concurrency);self.timeout=timeout;self.retries=retries;self.failure_limit=failure_limit;self.cooldown=cooldown
        self.failures=0;self.open_until=0;self.metrics={'success':0,'failed':0,'attempts':0,'rejected':0}
    async def predict(self,payload):
        deadline=time.monotonic()+self.timeout
        if time.monotonic()<self.open_until:
            self.metrics['rejected']+=1;raise CircuitOpen('Circuit cooling down')
        try:
            async with asyncio.timeout(max(0,deadline-time.monotonic())):
                async with self.semaphore:
                    if time.monotonic()<self.open_until:
                        self.metrics['rejected']+=1;raise CircuitOpen('Circuit cooling down')
                    for attempt in range(self.retries+1):
                        try:
                            self.metrics['attempts']+=1
                            result=await self.provider(payload)
                            self.failures=0;self.metrics['success']+=1;return result
                        except TransientError:
                            if attempt==self.retries:raise
                            await asyncio.sleep(.01*2**attempt)
        except (TransientError,TimeoutError):
            self.metrics['failed']+=1;self.failures+=1
            if self.failures>=self.failure_limit:self.open_until=time.monotonic()+self.cooldown
            raise
async def demo():
    async def provider(text):await asyncio.sleep(.01);return {'tokens_estimate':len(text.split()),'provider':'local demonstration'}
    s=Service(provider);results=await asyncio.gather(*(s.predict('explain retrieval systems') for _ in range(8)))
    return {'results':results,'metrics':s.metrics}
if __name__=='__main__':print(json.dumps(asyncio.run(demo()),indent=2))
