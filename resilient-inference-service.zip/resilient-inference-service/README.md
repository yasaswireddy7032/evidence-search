# Resilient Inference Service

An asynchronous inference adapter with bounded concurrency, deadlines, transient retries, and a circuit breaker.

**Status:** runnable portfolio reference implementation. Uses synthetic or hand-authored demonstration data. No employer code, customer data, or production performance claims.

## Run

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
python -m unittest -v
```

The default command prints a reproducible JSON demonstration. See `app.py` for the reusable Python API. `example-output.json` records the locally executed demo; it is not an external benchmark.

## Architecture

Caller → deadline including queue wait → semaphore → retryable provider call → metrics and circuit state. Python 3.11 structured timeout propagates cancellation.

## Validation

Tests exercise failure cases and behavioral invariants, in addition to the executable demo. GitHub Actions repeats tests and the demo on pushes and pull requests. CI has not run on GitHub until this repository is published.

## Limitations and next steps

Adapter library only: no HTTP server, real model provider, or production load test. Circuit state is process-local and cooldown recovery is simplified rather than single-probe half-open. Add shared quotas, randomized backoff, tracing, authenticated endpoints, provider-specific error mapping, and overload tests.

## Container

```bash
docker build -t resilient-inference-service .
docker run --rm resilient-inference-service
```

The Docker recipe is provided; local validation uses Python, not Docker.

## Responsible use

Review the code and understand its assumptions before deploying. Keep credentials in environment variables and exclude private data from commits. This project is an educational engineering baseline, not a production-certified service.

## Queueing benchmark

```bash
python benchmark.py --requests 100 --concurrency 4
```

The benchmark records successful request throughput, end-to-end p50/p95 latency including queue wait, failures, and observed peak concurrency. The provider sleeps for 10 ms; it is not a language model, and results are not LLM token-throughput claims. Use a real provider and representative request distribution to make deployment decisions. Record hardware and repeat runs before comparing performance.
